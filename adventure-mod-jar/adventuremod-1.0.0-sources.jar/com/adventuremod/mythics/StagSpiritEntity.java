package com.adventuremod.mythics;

import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1347;
import net.minecraft.class_1361;
import net.minecraft.class_1366;
import net.minecraft.class_1376;
import net.minecraft.class_1394;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.entity.ai.goal.*;

public class StagSpiritEntity extends class_1588 {
    private int teleportCooldown = 0;

    public StagSpiritEntity(class_1299<? extends class_1588> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new class_1347(this));
        this.field_6201.method_6277(1, new class_1366(this, 1.3D, true));
        this.field_6201.method_6277(2, new class_1394(this, 0.8D));
        this.field_6201.method_6277(3, new class_1361(this, class_1657.class, 12.0F));
        this.field_6201.method_6277(4, new class_1376(this));

        this.field_6185.method_6277(1, new class_1400<>(this, class_1657.class, 10, true, false, null));
        this.field_6185.method_6277(2, new class_1399(this));
    }

    public static class_5132.class_5133 createStagAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 60.0D)
                .method_26868(class_5134.field_23719, 0.35D)
                .method_26868(class_5134.field_23721, 8.0D)
                .method_26868(class_5134.field_23717, 24.0D)
                .method_26868(class_5134.field_23724, 6.0D);
    }

    @Override
    public void method_6007() {
        super.method_6007();
        if (!this.method_37908().field_9236) {
            if (teleportCooldown > 0) teleportCooldown--;

            class_1309 target = this.method_5968();
            if (target != null && teleportCooldown == 0 && this.method_5858(target) > 64.0D) {
                double x = target.method_23317() + (this.field_5974.method_43058() - 0.5) * 6.0D;
                double z = target.method_23321() + (this.field_5974.method_43058() - 0.5) * 6.0D;
                double y = target.method_23318();
                this.method_5859(x, y, z);
                teleportCooldown = 60;

                if (this.method_37908() instanceof class_3218 serverWorld) {
                    serverWorld.method_14199(class_2398.field_11207, x, y, z, 20, 0.5, 0.5, 0.5, 0.1);
                }
            }

            // Maintain Glowing on the target for 5 seconds at a time; refresh if needed
            if (target != null) {
                if (target.method_6059(class_1294.field_5912)) {
                    // Refresh duration 1 in 80 ticks
                    if (this.field_5974.method_43048(80) == 0) {
                        target.method_37222(new class_1293(class_1294.field_5912, 100, 0), this);
                    }
                } else if (this.field_5974.method_43057() < 0.10F) {
                    target.method_37222(new class_1293(class_1294.field_5912, 100, 0), this);
                }
            }
        }

        if (this.method_37908().field_9236) {
            this.method_37908().method_8406(class_2398.field_11207, this.method_23317() + (field_5974.method_43058() - 0.5), this.method_23318() + field_5974.method_43058(), this.method_23321() + (field_5974.method_43058() - 0.5), 0, 0, 0);
        }
    }

    @Override
    public boolean method_5643(class_1282 source, float amount) {
        if (source.method_5529() instanceof class_1309 attacker && this.method_5858(attacker) < 9.0D) {
            attacker.method_6005(0.5D, this.method_23317() - attacker.method_23317(), this.method_23321() - attacker.method_23321());
        }
        return super.method_5643(source, amount);
    }
}
