package com.adventuremod.mixin;

import com.adventuremod.movement.DashablePlayer;
import com.adventuremod.progression.PlayerProgression;
import com.adventuremod.progression.PlayerProgressionHolder;
import com.adventuremod.rpg.PlayerClass;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
public abstract class PlayerEntityMixin extends class_1309 implements DashablePlayer, PlayerProgressionHolder {
    @Unique
    private int adventuremod$jumpCount = 0;
    @Unique
    private int adventuremod$dashCooldown = 0;
    @Unique
    private int adventuremod$dashInvulTicks = 0;
    @Unique
    private int adventuremod$comboCount = 0;
    @Unique
    private int adventuremod$lastAttackTick = 0;
    @Unique
    private int adventuremod$wallJumpCooldown = 0;
    @Unique
    private final PlayerProgression adventuremod$progression = new PlayerProgression();

    protected PlayerEntityMixin(class_1299<? extends class_1309> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Override
    public PlayerProgression adventuremod$getProgression() {
        return this.adventuremod$progression;
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void onTick(CallbackInfo ci) {
        // Thirst
        this.adventuremod$progression.thirst.tick((class_1657) (Object) this);

        // Movement timers
        if (this.adventuremod$dashInvulTicks > 0) this.adventuremod$dashInvulTicks--;
        if (this.adventuremod$dashCooldown > 0) this.adventuremod$dashCooldown--;
        if (this.adventuremod$wallJumpCooldown > 0) this.adventuremod$wallJumpCooldown--;
        if (this.method_24828()) this.adventuremod$jumpCount = 0;
    }

    @Inject(method = "jump", at = @At("HEAD"), cancellable = true)
    private void onJump(CallbackInfo ci) {
        class_1657 player = (class_1657) (Object) this;

        // Wall jump: midair, colliding with a wall horizontally
        if (!player.method_24828() && player.field_5976 && this.adventuremod$wallJumpCooldown == 0) {
            double yawRad = Math.toRadians(player.method_36454());
            double dx = -Math.sin(yawRad) * 0.45;
            double dz = Math.cos(yawRad) * 0.45;
            // Push the player back away from the wall
            player.method_18800(-dx, 0.45, -dz);

            player.method_37908().method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(),
                    class_3417.field_14562, class_3419.field_15248, 0.8F, 1.2F);

            if (player.method_37908() instanceof class_3218 serverWorld) {
                serverWorld.method_14199(class_2398.field_11204, player.method_23317(), player.method_23318(), player.method_23321(), 8, 0.1, 0.1, 0.1, 0.05);
            }
            this.adventuremod$wallJumpCooldown = 10;
            ci.cancel();
            return;
        }

        // Double jump: midair, no more than 1 extra jump consumed
        if (!player.method_24828() && !player.field_5976 && this.adventuremod$jumpCount < 1) {
            this.adventuremod$jumpCount++;
            class_243 velocity = player.method_18798();
            player.method_18800(velocity.field_1352, 0.42, velocity.field_1350);

            player.method_37908().method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(),
                    class_3417.field_14869, class_3419.field_15248, 1.0F, 1.5F);

            if (player.method_37908() instanceof class_3218 serverWorld) {
                serverWorld.method_14199(class_2398.field_11204, player.method_23317(), player.method_23318() + 0.1, player.method_23321(), 6, 0.2, 0.1, 0.2, 0.02);
            }
            ci.cancel();
        }
    }

    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void onDamage(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        if (this.adventuremod$dashInvulTicks > 0) {
            // Allow void and creative kills to bypass dash i-frames
            String name = source.method_5525();
            if (!"outOfWorld".equals(name) && !"genericKill".equals(name)) {
                cir.setReturnValue(false);
            }
        }
    }

    @Override
    public void adventuremod$performDash() {
        if (this.adventuremod$dashCooldown == 0) {
            this.adventuremod$dashCooldown = 30; // 1.5 second cooldown
            this.adventuremod$dashInvulTicks = 10; // 0.5 second of invulnerability

            double yawRad = Math.toRadians(this.method_36454());
            double speed = 1.8D;
            double newVx = -Math.sin(yawRad) * speed;
            double newVz = Math.cos(yawRad) * speed;
            this.method_18800(newVx, 0.15D, newVz);
            this.field_6037 = true;

            this.method_37908().method_43128(null, this.method_23317(), this.method_23318(), this.method_23321(),
                    class_3417.field_14706, class_3419.field_15248, 1.2F, 1.2F);

            if (this.method_37908() instanceof class_3218 serverWorld) {
                serverWorld.method_14199(class_2398.field_11203, this.method_23317(), this.method_23318() + 0.5, this.method_23321(), 12, 0.3, 0.2, 0.3, 0.02);
            }
        }
    }

    @Inject(method = "attack", at = @At("HEAD"))
    private void onAttack(class_1297 target, CallbackInfo ci) {
        class_1657 player = (class_1657) (Object) this;
        if (player.method_6047().method_7960()) {
            int currentTick = player.field_6012;
            if (currentTick - this.adventuremod$lastAttackTick > 30) {
                this.adventuremod$comboCount = 0;
            } else {
                this.adventuremod$comboCount = (this.adventuremod$comboCount + 1) % 3;
            }
            this.adventuremod$lastAttackTick = currentTick;

            if (this.adventuremod$comboCount == 1 && target instanceof class_1309 livingTarget) {
                double yawRad = Math.toRadians(player.method_36454());
                livingTarget.method_6005(0.6F, Math.sin(yawRad), -Math.cos(yawRad));
            } else if (this.adventuremod$comboCount == 2 && target instanceof class_1309 livingTarget) {
                double yawRad = Math.toRadians(player.method_36454());
                livingTarget.method_6005(1.4F, Math.sin(yawRad), -Math.cos(yawRad));

                if (player.method_37908() instanceof class_3218 serverWorld) {
                    serverWorld.method_14199(class_2398.field_11227,
                            target.method_23317(), target.method_23323(0.5), target.method_23321(),
                            3, 0.2, 0.2, 0.2, 0.0);
                }
            }
        }
    }

    @Inject(method = "getAttributeValue", at = @At("RETURN"), cancellable = true)
    private void onGetAttributeValue(net.minecraft.class_6880<net.minecraft.class_1320> attribute, CallbackInfoReturnable<Double> cir) {
        PlayerClass pc = this.adventuremod$progression.playerClass;
        if (attribute.comp_349() == net.minecraft.class_5134.field_23719) {
            if (pc != PlayerClass.NONE) {
                cir.setReturnValue(cir.getReturnValue() * pc.speedMultiplier);
            }
            return;
        }
        if (attribute.comp_349() == net.minecraft.class_5134.field_23721) {
            class_1657 player = (class_1657) (Object) this;
            if (player.method_6047().method_7960()) {
                // Fist combo: punch 1 = 4 damage, punch 3 = 6 damage, then class multiplier
                double baseFist = 4.0D;
                if (this.adventuremod$comboCount == 2) baseFist = 6.0D;
                cir.setReturnValue(baseFist * pc.combatMultiplier);
            } else if (pc != PlayerClass.NONE) {
                cir.setReturnValue(cir.getReturnValue() * pc.combatMultiplier);
            }
        }
    }

    @Inject(method = "writeCustomDataToNbt", at = @At("HEAD"))
    private void writeProgressionNbt(class_2487 nbt, CallbackInfo ci) {
        nbt.method_10566("AdventureModProgression", this.adventuremod$progression.toNbt());
    }

    @Inject(method = "readCustomDataFromNbt", at = @At("HEAD"))
    private void readProgressionNbt(class_2487 nbt, CallbackInfo ci) {
        if (nbt.method_10545("AdventureModProgression")) {
            PlayerProgression loaded = PlayerProgression.fromNbt(nbt.method_10562("AdventureModProgression"));
            // Re-assign fields since final can't be replaced
            this.adventuremod$progression.skills.replaceWith(loaded.skills);
            this.adventuremod$progression.thirst.replaceWith(loaded.thirst);
            this.adventuremod$progression.playerClass = loaded.playerClass;
        }
    }
}
