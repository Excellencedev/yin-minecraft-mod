package com.adventuremod.mixin;

import com.adventuremod.skills.ModSkills;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin {

    @Inject(method = "onDeath", at = @At("HEAD"))
    private void onDeath(class_1282 source, CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;
        if (self.method_37908().field_9236) return;
        if (source.method_5529() instanceof class_1657 player) {
            ModSkills.onKill(player, self);
        }
    }

    @Inject(method = "damage", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;blockedByShield(Lnet/minecraft/entity/damage/DamageSource;)Z"))
    private void checkParry(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        class_1309 defender = (class_1309) (Object) this;
        if (defender instanceof class_1657 player) {
            if (defender.method_6061(source)) {
                int useTicks = defender.method_6048();
                if (useTicks <= 8) {
                    player.method_37908().method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(),
                            class_3417.field_14833, class_3419.field_15248, 1.0F, 1.8F);

                    if (player.method_37908() instanceof class_3218 serverWorld) {
                        serverWorld.method_14199(class_2398.field_11205,
                                player.method_23317(), player.method_23323(0.5), player.method_23321(),
                                15, 0.3, 0.3, 0.3, 0.15);
                    }

                    if (source.method_5529() instanceof class_1309 attacker) {
                        attacker.method_37222(new class_1293(class_1294.field_5909, 40, 9), player);
                        attacker.method_37222(new class_1293(class_1294.field_5911, 40, 9), player);
                        attacker.method_6005(1.0D, player.method_23317() - attacker.method_23317(), player.method_23321() - attacker.method_23321());
                    }
                }
            }
        }
    }
}
