package com.adventuremod.skills;

import com.adventuremod.AdventureMod;
import com.adventuremod.entity.DeerEntity;
import com.adventuremod.entity.WildBoarEntity;
import com.adventuremod.mythics.StagSpiritEntity;
import com.adventuremod.bosses.ForestGuardianBossEntity;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2302;

public class ModSkills {
    public static void registerSkills() {
        AdventureMod.LOGGER.info("Registering Skills for " + AdventureMod.MOD_ID);

        // Farming XP: break mature crops
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            if (!world.field_9236 && state.method_26204() instanceof class_2302 crop && crop.method_9825(state)) {
                PlayerSkills.addFarmingXp(player, 4);
            }
            return true;
        });
    }

    /**
     * Called by mixin when a player kills a living entity.
     * Awards combat XP for mobs, hunting XP for game animals.
     */
    public static void onKill(class_1657 player, class_1309 victim) {
        if (player.method_37908().field_9236) return;

        if (victim instanceof ForestGuardianBossEntity) {
            PlayerSkills.addCombatXp(player, 200);
            PlayerSkills.addHuntingXp(player, 200);
            return;
        }
        if (victim instanceof StagSpiritEntity) {
            PlayerSkills.addCombatXp(player, 80);
            PlayerSkills.addHuntingXp(player, 80);
            return;
        }
        if (victim instanceof WildBoarEntity || victim instanceof DeerEntity) {
            PlayerSkills.addHuntingXp(player, 30);
        }
        if (victim instanceof net.minecraft.class_1569) {
            PlayerSkills.addCombatXp(player, 10);
        }
    }
}
