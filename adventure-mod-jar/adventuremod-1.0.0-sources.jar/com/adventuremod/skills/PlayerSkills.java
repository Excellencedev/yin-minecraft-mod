package com.adventuremod.skills;

import com.adventuremod.progression.PlayerProgressionHolder;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class PlayerSkills {
    private int huntingLevel = 1;
    private int combatLevel = 1;
    private int farmingLevel = 1;
    private int totalHuntingXp = 0;
    private int totalCombatXp = 0;
    private int totalFarmingXp = 0;

    public void addHuntingXp(int amount) {
        addHuntingXp(amount, null);
    }

    public void addHuntingXp(int amount, class_1657 cause) {
        if (amount <= 0) return;
        totalHuntingXp += amount;
        int newLevel = calculateLevel(totalHuntingXp);
        if (newLevel > huntingLevel && cause instanceof class_3222 sp) {
            sp.method_7353(class_2561.method_43470("§a[Skill] Hunting leveled up: " + (newLevel - 1) + " -> " + newLevel), true);
        }
        huntingLevel = newLevel;
    }

    public void addCombatXp(int amount) {
        addCombatXp(amount, null);
    }

    public void addCombatXp(int amount, class_1657 cause) {
        if (amount <= 0) return;
        totalCombatXp += amount;
        int newLevel = calculateLevel(totalCombatXp);
        if (newLevel > combatLevel && cause instanceof class_3222 sp) {
            sp.method_7353(class_2561.method_43470("§c[Skill] Combat leveled up: " + (newLevel - 1) + " -> " + newLevel), true);
        }
        combatLevel = newLevel;
    }

    public void addFarmingXp(int amount) {
        addFarmingXp(amount, null);
    }

    public void addFarmingXp(int amount, class_1657 cause) {
        if (amount <= 0) return;
        totalFarmingXp += amount;
        int newLevel = calculateLevel(totalFarmingXp);
        if (newLevel > farmingLevel && cause instanceof class_3222 sp) {
            sp.method_7353(class_2561.method_43470("§e[Skill] Farming leveled up: " + (newLevel - 1) + " -> " + newLevel), true);
        }
        farmingLevel = newLevel;
    }

    private int calculateLevel(int totalXp) {
        return Math.min(50, (int) (Math.sqrt(totalXp / 50.0)) + 1);
    }

    public int getHuntingLevel() { return huntingLevel; }
    public int getCombatLevel() { return combatLevel; }
    public int getFarmingLevel() { return farmingLevel; }
    public int getTotalHuntingXp() { return totalHuntingXp; }
    public int getTotalCombatXp() { return totalCombatXp; }
    public int getTotalFarmingXp() { return totalFarmingXp; }

    public void replaceWith(PlayerSkills other) {
        this.huntingLevel = other.huntingLevel;
        this.combatLevel = other.combatLevel;
        this.farmingLevel = other.farmingLevel;
        this.totalHuntingXp = other.totalHuntingXp;
        this.totalCombatXp = other.totalCombatXp;
        this.totalFarmingXp = other.totalFarmingXp;
    }

    public class_2487 toNbt() {
        class_2487 tag = new class_2487();
        tag.method_10569("huntingLevel", huntingLevel);
        tag.method_10569("combatLevel", combatLevel);
        tag.method_10569("farmingLevel", farmingLevel);
        tag.method_10569("totalHuntingXp", totalHuntingXp);
        tag.method_10569("totalCombatXp", totalCombatXp);
        tag.method_10569("totalFarmingXp", totalFarmingXp);
        return tag;
    }

    public static PlayerSkills fromNbt(class_2487 tag) {
        PlayerSkills skills = new PlayerSkills();
        skills.huntingLevel = Math.max(1, tag.method_10550("huntingLevel"));
        skills.combatLevel = Math.max(1, tag.method_10550("combatLevel"));
        skills.farmingLevel = Math.max(1, tag.method_10550("farmingLevel"));
        skills.totalHuntingXp = tag.method_10550("totalHuntingXp");
        skills.totalCombatXp = tag.method_10550("totalCombatXp");
        skills.totalFarmingXp = tag.method_10550("totalFarmingXp");
        return skills;
    }

    public void addXp(String skill, int amount) {
        switch (skill) {
            case "hunting" -> addHuntingXp(amount);
            case "combat" -> addCombatXp(amount);
            case "farming" -> addFarmingXp(amount);
        }
    }

    // ---- Static helpers (used by gameplay code that does not hold a PlayerProgression ref) ----

    public static void addHuntingXp(class_1657 player, int amount) {
        if (player instanceof PlayerProgressionHolder h) {
            h.adventuremod$getProgression().skills.addHuntingXp(amount, player);
        }
    }

    public static void addCombatXp(class_1657 player, int amount) {
        if (player instanceof PlayerProgressionHolder h) {
            h.adventuremod$getProgression().skills.addCombatXp(amount, player);
        }
    }

    public static void addFarmingXp(class_1657 player, int amount) {
        if (player instanceof PlayerProgressionHolder h) {
            h.adventuremod$getProgression().skills.addFarmingXp(amount, player);
        }
    }
}
