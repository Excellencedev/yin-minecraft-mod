package com.adventuremod.rpg;

import com.adventuremod.AdventureMod;
import com.adventuremod.progression.PlayerProgressionHolder;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import java.util.Arrays;

public class ModRpg {
    private static final SuggestionProvider<class_2168> CLASS_SUGGESTIONS = (context, builder) ->
            class_2172.method_9264(Arrays.stream(PlayerClass.values()).map(PlayerClass::getName), builder);

    public static void registerRpg() {
        AdventureMod.LOGGER.info("Registering RPG for " + AdventureMod.MOD_ID);
        CommandRegistrationCallback.EVENT.register(ModRpg::registerCommands);
    }

    private static void registerCommands(CommandDispatcher<class_2168> dispatcher, net.minecraft.class_7157 registryAccess, net.minecraft.class_2170.class_5364 environment) {
        dispatcher.register(net.minecraft.class_2170.method_9247("class")
                .then(net.minecraft.class_2170.method_9244("name", StringArgumentType.string())
                        .suggests(CLASS_SUGGESTIONS)
                        .executes(ModRpg::setClass)
                )
                .executes(ModRpg::showClass)
        );
    }

    private static int setClass(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        String name = StringArgumentType.getString(context, "name");
        PlayerClass pc = PlayerClass.fromName(name);
        if (pc == PlayerClass.NONE && !"none".equalsIgnoreCase(name)) {
            source.method_9213(class_2561.method_43470("Unknown class: " + name + ". Valid: hunter, warrior, scout, none"));
            return 0;
        }
        if (source.method_44023() instanceof PlayerProgressionHolder holder) {
            holder.adventuremod$getProgression().playerClass = pc;
            source.method_9226(() -> class_2561.method_43470("§6Set your class to " + pc.getName()), true);
            return 1;
        }
        return 0;
    }

    private static int showClass(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        if (source.method_44023() instanceof PlayerProgressionHolder holder) {
            PlayerClass pc = holder.adventuremod$getProgression().playerClass;
            source.method_9226(() -> class_2561.method_43470("§6Current class: " + pc.getName()), false);
            return 1;
        }
        return 0;
    }
}
