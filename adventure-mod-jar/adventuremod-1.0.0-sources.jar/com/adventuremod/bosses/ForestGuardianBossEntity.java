package com.adventuremod.bosses;

import com.adventuremod.item.ModItems;
import net.minecraft.class_1259;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1347;
import net.minecraft.class_1361;
import net.minecraft.class_1366;
import net.minecraft.class_1376;
import net.minecraft.class_1394;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3213;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.entity.ai.goal.*;
import java.util.List;

public class ForestGuardianBossEntity extends class_1588 {
    private final class_3213 bossBar;
    private int phase = 1;
    private int attackCooldown = 0;

    public ForestGuardianBossEntity(class_1299<? extends class_1588> entityType, class_1937 world) {
        super(entityType, world);
        this.bossBar = new class_3213(
                class_2561.method_43470("Forest Guardian"),
                class_1259.class_1260.field_5785,
                class_1259.class_1261.field_5795
        );
        this.method_5971();
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new class_1347(this));
        this.field_6201.method_6277(1, new class_1366(this, 1.2D, true));
        this.field_6201.method_6277(2, new class_1394(this, 0.8D));
        this.field_6201.method_6277(3, new class_1361(this, class_1657.class, 16.0F));
        this.field_6201.method_6277(4, new class_1376(this));

        this.field_6185.method_6277(1, new class_1400<>(this, class_1657.class, 0, true, false, null));
        this.field_6185.method_6277(2, new class_1399(this));
    }

    public static class_5132.class_5133 createBossAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 200.0D)
                .method_26868(class_5134.field_23719, 0.28D)
                .method_26868(class_5134.field_23721, 12.0D)
                .method_26868(class_5134.field_23717, 32.0D)
                .method_26868(class_5134.field_23724, 10.0D)
                .method_26868(class_5134.field_23718, 1.0D);
    }

    @Override
    public void method_6007() {
        super.method_6007();
        if (!this.method_37908().field_9236) {
            this.bossBar.method_5408(this.method_6032() / this.method_6063());

            if (this.method_6032() < this.method_6063() * 0.5F && phase == 1) {
                phase = 2;
                this.method_5783(class_3417.field_14792, 1.0F, 1.0F);
                if (this.method_37908() instanceof class_3218 serverWorld) {
                    serverWorld.method_14199(class_2398.field_11231, this.method_23317(), this.method_23318() + 1, this.method_23321(), 30, 1, 1, 1, 0.1);
                }
                this.method_5996(class_5134.field_23721).method_6192(18.0D);
                this.method_5996(class_5134.field_23719).method_6192(0.36D);
            }

            if (attackCooldown > 0) attackCooldown--;

            class_1309 target = this.method_5968();
            if (target != null && attackCooldown == 0) {
                if (phase == 2 && this.method_5858(target) < 100.0D) {
                    double dx = target.method_23317() - this.method_23317();
                    double dz = target.method_23321() - this.method_23321();
                    double dist = Math.sqrt(dx * dx + dz * dz);
                    if (dist > 0) {
                        this.method_18800(dx / dist * 1.5D, 0.3D, dz / dist * 1.5D);
                        this.field_6037 = true;
                    }
                    attackCooldown = 60;
                } else if (this.method_5858(target) < 16.0D) {
                    attackCooldown = 20;
                }

                // Phase 2: AoE ground slam every 5 seconds
                if (phase == 2 && this.field_6012 % 100 == 0) {
                    class_238 slam = this.method_5829().method_1009(6.0D, 2.0D, 6.0D);
                    List<class_1309> near = this.method_37908().method_8390(class_1309.class, slam, e -> e != this && e.method_5805());
                    for (class_1309 e : near) {
                        e.method_5643(this.method_48923().method_48812(this), 8.0F);
                        e.method_37222(new class_1293(class_1294.field_5909, 60, 1), this);
                        e.method_6005(1.0D, this.method_23317() - e.method_23317(), this.method_23321() - e.method_23321());
                    }
                    this.method_5783(class_3417.field_38830, 1.5F, 0.7F);
                    if (this.method_37908() instanceof class_3218 sw) {
                        sw.method_14199(class_2398.field_11236, this.method_23317(), this.method_23318(), this.method_23321(), 8, 3, 0.5, 3, 0.1);
                    }
                }
            }
        } else {
            if (this.field_5974.method_43057() < 0.1F) {
                this.method_37908().method_8406(class_2398.field_11231,
                        this.method_23317() + (field_5974.method_43058() - 0.5) * 2,
                        this.method_23318() + field_5974.method_43058() * 2,
                        this.method_23321() + (field_5974.method_43058() - 0.5) * 2,
                        0, 0, 0);
            }
        }
    }

    @Override
    public void method_5837(class_3222 player) {
        super.method_5837(player);
        this.bossBar.method_14088(player);
    }

    @Override
    public void method_5742(class_3222 player) {
        super.method_5742(player);
        this.bossBar.method_14089(player);
    }

    @Override
    public void method_6078(class_1282 source) {
        super.method_6078(source);
        // The MobEntity.dropEquipment signature changed in 1.21.1 yarn; we drop our
        // boss loot directly here instead.
        this.method_5706(ModItems.ANTLER_GREATSWORD);
        this.method_5870(net.minecraft.class_1802.field_8733, 3 + this.field_5974.method_43048(3));
    }

    @Override
    protected int method_6110() {
        // Bosses drop 100 XP on death
        return 100;
    }
}
