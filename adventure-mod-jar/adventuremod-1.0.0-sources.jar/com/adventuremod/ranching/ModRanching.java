package com.adventuremod.ranching;

import com.adventuremod.AdventureMod;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import net.minecraft.class_3966;

public class ModRanching {
    public static void registerRanching() {
        AdventureMod.LOGGER.info("Registering Ranching for " + AdventureMod.MOD_ID);

        // Right-click an adult non-baby animal with a bucket: milk.
        UseEntityCallback.EVENT.register((class_1657 player, class_1937 world, class_1268 hand, net.minecraft.class_1297 entity, class_3966 hitResult) -> {
            class_1799 stack = player.method_5998(hand);
            if (!(entity instanceof class_1429 animal) || animal.method_6109()) {
                return class_1269.field_5811;
            }
            if (!stack.method_31574(class_1802.field_8550)) return class_1269.field_5811;
            // Only milk animals that already implement milking: cow, goat, sheep (mooshroom)
            if (animal instanceof net.minecraft.class_1430
                    || animal instanceof net.minecraft.class_6053
                    || animal instanceof net.minecraft.class_1438
                    || animal instanceof net.minecraft.class_1472) {
                if (world.field_9236) return class_1269.field_5812;
                stack.method_7934(1);
                class_1799 milk = new class_1799(class_1802.field_8103);
                if (stack.method_7960()) player.method_6122(hand, milk);
                else player.method_31548().method_7394(milk);
                animal.method_5783(class_3417.field_14691, 1.0F, 1.0F);
                return class_1269.field_5812;
            }
            return class_1269.field_5811;
        });
    }
}
