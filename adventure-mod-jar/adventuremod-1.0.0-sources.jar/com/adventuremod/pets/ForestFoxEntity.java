package com.adventuremod.pets;

import com.adventuremod.ai.TrackOwnerTargetGoal;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1321;
import net.minecraft.class_1347;
import net.minecraft.class_1350;
import net.minecraft.class_1361;
import net.minecraft.class_1366;
import net.minecraft.class_1376;
import net.minecraft.class_1386;
import net.minecraft.class_1391;
import net.minecraft.class_1394;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1406;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.entity.ai.goal.*;
import org.jetbrains.annotations.Nullable;

public class ForestFoxEntity extends class_1321 {
    public ForestFoxEntity(class_1299<? extends class_1321> entityType, class_1937 world) {
        super(entityType, world);
        this.method_6173(false, false);
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new class_1347(this));
        this.field_6201.method_6277(1, new class_1386(this));
        this.field_6201.method_6277(2, new class_1366(this, 1.2D, true));
        this.field_6201.method_6277(3, new class_1350(this, 1.1D, 5.0F, 2.0F));
        this.field_6201.method_6277(4, new class_1391(this, 1.1D, class_1856.method_8091(class_1802.field_16998, class_1802.field_28659), false));
        this.field_6201.method_6277(5, new class_1394(this, 0.8D));
        this.field_6201.method_6277(6, new class_1361(this, class_1657.class, 8.0F));
        this.field_6201.method_6277(7, new class_1376(this));

        this.field_6185.method_6277(1, new TrackOwnerTargetGoal(this));
        this.field_6185.method_6277(2, new class_1406(this));
        this.field_6185.method_6277(3, new class_1399(this));
        this.field_6185.method_6277(4, new class_1400<>(this, class_1588.class, 10, true, false, null));
    }

    public static class_5132.class_5133 createFoxAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 20.0D)
                .method_26868(class_5134.field_23719, 0.35D)
                .method_26868(class_5134.field_23721, 3.0D);
    }

    @Override
    public class_1269 method_5992(class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (stack.method_31574(class_1802.field_16998) || stack.method_31574(class_1802.field_28659)) {
            if (!this.method_6181()) {
                if (!player.method_31549().field_7477) stack.method_7934(1);
                if (!this.method_37908().field_9236) {
                    if (this.field_5974.method_43048(3) == 0) {
                        this.method_6170(player);
                        this.method_37908().method_8421(this, (byte) 7);
                    } else {
                        this.method_37908().method_8421(this, (byte) 6);
                    }
                }
                return class_1269.field_5812;
            }
            if (this.method_6032() < this.method_6063()) {
                this.method_6025(4.0F);
                if (!player.method_31549().field_7477) stack.method_7934(1);
                this.method_5783(class_3417.field_18060, 1.0F, 1.0F);
                return class_1269.field_5812;
            }
        }
        if (this.method_6181() && this.method_6171(player)) {
            if (!this.method_37908().field_9236) {
                this.method_24346(!this.method_24345());
                this.field_6189.method_6340();
                this.method_5980(null);
            }
            return class_1269.field_5812;
        }
        return super.method_5992(player, hand);
    }

    @Nullable
    @Override
    public class_1296 method_5613(class_3218 world, class_1296 entity) {
        return null;
    }

    @Override
    public boolean method_6481(class_1799 stack) {
        return false; // Foxes are tamed, not bred
    }
}
