package com.adventuremod.client;

import com.adventuremod.client.renderer.*;
import com.adventuremod.entity.ModEntities;
import com.adventuremod.movement.DashPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class AdventureModClient implements ClientModInitializer {
    private static class_304 dashKeyBinding;

    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.WILD_BOAR, WildBoarRenderer::new);
        EntityRendererRegistry.register(ModEntities.DEER, DeerRenderer::new);
        EntityRendererRegistry.register(ModEntities.GUARD_VILLAGER, GuardVillagerRenderer::new);
        EntityRendererRegistry.register(ModEntities.RIDEABLE_BOAR, RideableBoarRenderer::new);
        EntityRendererRegistry.register(ModEntities.FOREST_FOX, ForestFoxRenderer::new);
        EntityRendererRegistry.register(ModEntities.STAG_SPIRIT, StagSpiritRenderer::new);
        EntityRendererRegistry.register(ModEntities.FOREST_GUARDIAN, ForestGuardianRenderer::new);

        dashKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.adventuremod.dash",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_LEFT_ALT,
                "category.adventuremod.movement"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 != null) {
                while (dashKeyBinding.method_1436()) {
                    ClientPlayNetworking.send(new DashPayload(true));
                }
            }
        });
    }
}
