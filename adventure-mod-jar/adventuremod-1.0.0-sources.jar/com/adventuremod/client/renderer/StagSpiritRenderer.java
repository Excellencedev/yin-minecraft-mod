package com.adventuremod.client.renderer;

import com.adventuremod.AdventureMod;
import com.adventuremod.mythics.StagSpiritEntity;
import net.minecraft.class_2960;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_6227;
import net.minecraft.class_927;

public class StagSpiritRenderer extends class_927<StagSpiritEntity, class_583<StagSpiritEntity>> {
    @SuppressWarnings({"unchecked", "rawtypes"})
    public StagSpiritRenderer(class_5617.class_5618 context) {
        // GoatEntityModel is bounded to GoatEntity; cast to EntityModel<StagSpiritEntity>.
        super(context, (class_583) new class_6227(context.method_32167(class_5602.field_32581)), 1.0F);
    }

    @Override
    public class_2960 getTexture(StagSpiritEntity entity) {
        return class_2960.method_60655(AdventureMod.MOD_ID, "textures/entity/stag_spirit.png");
    }
}
