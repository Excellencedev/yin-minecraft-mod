package com.adventuremod.client.renderer;

import com.adventuremod.AdventureMod;
import com.adventuremod.entity.WildBoarEntity;
import net.minecraft.class_2960;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_587;
import net.minecraft.class_927;

public class WildBoarRenderer extends class_927<WildBoarEntity, class_587<WildBoarEntity>> {
    public WildBoarRenderer(class_5617.class_5618 context) {
        super(context, new class_587<>(context.method_32167(class_5602.field_27621)), 0.7F);
    }

    @Override
    public class_2960 getTexture(WildBoarEntity entity) {
        return class_2960.method_60655(AdventureMod.MOD_ID, "textures/entity/wild_boar.png");
    }
}
