package com.adventuremod.client.renderer;

import com.adventuremod.AdventureMod;
import com.adventuremod.pets.ForestFoxEntity;
import net.minecraft.class_2960;
import net.minecraft.class_4041;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_927;

public class ForestFoxRenderer extends class_927<ForestFoxEntity, class_583<ForestFoxEntity>> {
    @SuppressWarnings({"unchecked", "rawtypes"})
    public ForestFoxRenderer(class_5617.class_5618 context) {
        // FoxEntityModel is bounded to FoxEntity; cast to EntityModel<ForestFoxEntity> for the
        // renderer's type parameter. Model renders visually; type safety is bypassed.
        super(context, (class_583) new class_4041(context.method_32167(class_5602.field_27566)), 0.4F);
    }

    @Override
    public class_2960 getTexture(ForestFoxEntity entity) {
        return class_2960.method_60655(AdventureMod.MOD_ID, "textures/entity/forest_fox.png");
    }
}
