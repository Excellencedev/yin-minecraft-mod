package com.adventuremod.client.renderer;

import com.adventuremod.AdventureMod;
import com.adventuremod.entity.DeerEntity;
import net.minecraft.class_2960;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_6227;
import net.minecraft.class_927;

public class DeerRenderer extends class_927<DeerEntity, class_583<DeerEntity>> {
    @SuppressWarnings({"unchecked", "rawtypes"})
    public DeerRenderer(class_5617.class_5618 context) {
        // GoatEntityModel is bounded to GoatEntity; we cast it to a raw EntityModel<DeerEntity>
        // so the renderer can be parameterized on DeerEntity. The model still renders the
        // deer visually; it just isn't strictly type-checked at compile time.
        super(context, (class_583) new class_6227(context.method_32167(class_5602.field_32581)), 0.6F);
    }

    @Override
    public class_2960 getTexture(DeerEntity entity) {
        if (entity.hasAntlers()) {
            return class_2960.method_60655(AdventureMod.MOD_ID, "textures/entity/deer_antlers.png");
        }
        return class_2960.method_60655(AdventureMod.MOD_ID, "textures/entity/deer.png");
    }
}
