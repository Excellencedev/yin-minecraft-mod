package com.adventuremod.client.renderer;

import com.adventuremod.AdventureMod;
import com.adventuremod.bosses.ForestGuardianBossEntity;
import net.minecraft.class_2960;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_571;
import net.minecraft.class_583;
import net.minecraft.class_927;

public class ForestGuardianRenderer extends class_927<ForestGuardianBossEntity, class_583<ForestGuardianBossEntity>> {
    @SuppressWarnings({"unchecked", "rawtypes"})
    public ForestGuardianRenderer(class_5617.class_5618 context) {
        // RavagerEntityModel is no longer generic in 1.21.1 yarn; cast to EntityModel<Boss>.
        super(context, (class_583) new class_571(context.method_32167(class_5602.field_27591)), 1.2F);
    }

    @Override
    public class_2960 getTexture(ForestGuardianBossEntity entity) {
        return class_2960.method_60655(AdventureMod.MOD_ID, "textures/entity/forest_guardian.png");
    }
}
