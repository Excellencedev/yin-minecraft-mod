package com.adventuremod.client.renderer;

import com.adventuremod.AdventureMod;
import com.adventuremod.entity.GuardVillagerEntity;
import net.minecraft.class_2960;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_572;
import net.minecraft.class_909;

public class GuardVillagerRenderer extends class_909<GuardVillagerEntity, class_572<GuardVillagerEntity>> {
    public GuardVillagerRenderer(class_5617.class_5618 context) {
        super(context, new class_572<>(context.method_32167(class_5602.field_27577)), 0.5F);
    }

    @Override
    public class_2960 getTexture(GuardVillagerEntity entity) {
        if (entity.method_6181()) {
            return class_2960.method_60655(AdventureMod.MOD_ID, "textures/entity/guard_villager_hired.png");
        }
        return class_2960.method_60655(AdventureMod.MOD_ID, "textures/entity/guard_villager.png");
    }
}
