package com.adventuremod.villager;

import com.adventuremod.AdventureMod;
import com.adventuremod.entity.ModEntities;
import com.adventuremod.item.ModItems;
import com.google.common.collect.ImmutableSet;
import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.fabricmc.fabric.api.object.builder.v1.world.poi.PointOfInterestHelper;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1914;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_3852;
import net.minecraft.class_4158;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_9306;
import java.util.Optional;

public class ModVillagers {
    public static final class_2248 HUNTER_TABLE = class_2378.method_10230(
            class_7923.field_41175,
            class_2960.method_60655(AdventureMod.MOD_ID, "hunter_table"),
            new class_2248(class_4970.class_2251.method_9630(class_2246.field_16331))
    );

    public static final class_1792 HUNTER_TABLE_ITEM = class_2378.method_10230(
            class_7923.field_41178,
            class_2960.method_60655(AdventureMod.MOD_ID, "hunter_table"),
            new class_1747(HUNTER_TABLE, new class_1792.class_1793())
    );

    public static final class_5321<class_4158> HUNTER_POI_KEY = class_5321.method_29179(
            class_7923.field_41128.method_30517(),
            class_2960.method_60655(AdventureMod.MOD_ID, "hunter_poi")
    );

    public static final class_4158 HUNTER_POI = PointOfInterestHelper.register(
            class_2960.method_60655(AdventureMod.MOD_ID, "hunter_poi"),
            1, 1, HUNTER_TABLE
    );

    public static final class_3852 HUNTER_PROFESSION = class_2378.method_10230(
            class_7923.field_41195,
            class_2960.method_60655(AdventureMod.MOD_ID, "hunter"),
            new class_3852(
                    "hunter",
                    entry -> entry.method_40225(HUNTER_POI_KEY),
                    entry -> entry.method_40225(HUNTER_POI_KEY),
                    ImmutableSet.of(),
                    ImmutableSet.of(),
                    class_3417.field_20670
            )
    );

    public static void registerVillagers() {
        AdventureMod.LOGGER.info("Registering Villager Professions for " + AdventureMod.MOD_ID);
        registerTrades();
    }

    private static void registerTrades() {
        // Level 1: Meat for Emeralds; sells arrows
        TradeOfferHelper.registerVillagerOffers(HUNTER_PROFESSION, 1, factories -> {
            factories.add((entity, random) -> new class_1914(
                    new class_9306(ModItems.RAW_BOAR_MEAT, 4),
                    new class_1799(class_1802.field_8687, 1),
                    16, 2, 0.05F
            ));
            factories.add((entity, random) -> new class_1914(
                    new class_9306(ModItems.RAW_VENISON, 4),
                    new class_1799(class_1802.field_8687, 1),
                    16, 2, 0.05F
            ));
            factories.add((entity, random) -> new class_1914(
                    new class_9306(class_1802.field_8687, 1),
                    new class_1799(class_1802.field_8107, 8),
                    12, 1, 0.05F
            ));
        });

        // Level 2: Tusks/Antlers for Emeralds; sells armor
        TradeOfferHelper.registerVillagerOffers(HUNTER_PROFESSION, 2, factories -> {
            factories.add((entity, random) -> new class_1914(
                    new class_9306(ModItems.BOAR_TUSK, 2),
                    new class_1799(class_1802.field_8687, 3),
                    12, 5, 0.05F
            ));
            factories.add((entity, random) -> new class_1914(
                    new class_9306(ModItems.DEER_ANTLER, 2),
                    new class_1799(class_1802.field_8687, 3),
                    12, 5, 0.05F
            ));
            factories.add((entity, random) -> new class_1914(
                    new class_9306(class_1802.field_8687, 4),
                    new class_1799(class_1802.field_8577, 1),
                    8, 4, 0.05F
            ));
        });

        // Level 3: Custom Weapons for Emeralds
        TradeOfferHelper.registerVillagerOffers(HUNTER_PROFESSION, 3, factories -> {
            factories.add((entity, random) -> new class_1914(
                    new class_9306(class_1802.field_8687, 8),
                    new class_1799(ModItems.BOAR_TUSK_DAGGER, 1),
                    3, 10, 0.05F
            ));
            factories.add((entity, random) -> new class_1914(
                    new class_9306(class_1802.field_8687, 12),
                    new class_1799(ModItems.ANTLER_GREATSWORD, 1),
                    3, 15, 0.05F
            ));
        });

        // Level 4: Hunter Bows and Tipped Arrows
        TradeOfferHelper.registerVillagerOffers(HUNTER_PROFESSION, 4, factories -> {
            factories.add((entity, random) -> new class_1914(
                    new class_9306(class_1802.field_8687, 16),
                    new class_1799(ModItems.HUNTER_BOW, 1),
                    3, 20, 0.05F
            ));
            factories.add((entity, random) -> new class_1914(
                    new class_9306(class_1802.field_8687, 4),
                    new class_1799(class_1802.field_8236, 8),
                    12, 10, 0.05F
            ));
        });
    }
}
