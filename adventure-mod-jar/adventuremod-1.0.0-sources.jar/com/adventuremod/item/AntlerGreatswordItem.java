package com.adventuremod.item;

import java.util.List;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1569;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_3218;

public class AntlerGreatswordItem extends class_1829 {
    public AntlerGreatswordItem(class_1832 material, class_1793 settings) {
        super(material, settings);
    }

    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        class_1282 damageSource = attacker.method_48923().method_48802(attacker instanceof net.minecraft.class_1657 player ? player : null);
        class_238 sweepBox = target.method_5829().method_1009(3.0D, 1.0D, 3.0D);
        List<class_1309> targets = target.method_37908().method_8390(class_1309.class, sweepBox, 
                entity -> entity != attacker && entity != target && (entity instanceof class_1569 || entity instanceof class_1309));

        for (class_1309 nearbyTarget : targets) {
            nearbyTarget.method_5643(damageSource, 3.0f);
            double dx = nearbyTarget.method_23317() - attacker.method_23317();
            double dz = nearbyTarget.method_23321() - attacker.method_23321();
            double length = Math.sqrt(dx * dx + dz * dz);
            if (length > 0) {
                nearbyTarget.method_6005(1.2D, -dx / length, -dz / length);
            }
        }

        if (attacker.method_37908() instanceof class_3218 serverWorld) {
            serverWorld.method_14199(class_2398.field_11227, 
                    target.method_23317(), target.method_23323(0.5), target.method_23321(), 
                    5, 0.5, 0.2, 0.5, 0.0);
        }

        return super.method_7873(stack, target, attacker);
    }
}
