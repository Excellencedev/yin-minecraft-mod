package com.adventuremod.item;

import com.adventuremod.survival.ThirstManager;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public class WildBerryItem extends class_1792 {
    public WildBerryItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
        class_1799 result = super.method_7861(stack, world, user);
        if (!world.field_9236 && user instanceof class_1657 player) {
            ThirstManager tm = ThirstManager.get(player);
            if (tm != null) tm.drink(2, 0.5f);
        }
        return result;
    }
}
