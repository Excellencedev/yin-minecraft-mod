package com.adventuremod.item;

import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1667;
import net.minecraft.class_1753;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;

public class HunterBowItem extends class_1753 {
    public HunterBowItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public void method_7840(class_1799 stack, class_1937 world, class_1309 user, int remainingUseTicks) {
        if (user instanceof class_1657 playerEntity) {
            class_1799 arrowStack = playerEntity.method_18808(stack);
            if (!arrowStack.method_7960() || playerEntity.method_31549().field_7477) {
                if (arrowStack.method_7960()) {
                    arrowStack = new class_1799(class_1802.field_8107);
                }

                int useTime = this.method_7881(stack, user) - remainingUseTicks;
                float pullProgress = (float) useTime / 12.0f;
                pullProgress = (pullProgress * pullProgress + pullProgress * 2.0F) / 3.0F;
                if (pullProgress > 1.0F) {
                    pullProgress = 1.0F;
                }

                if (!((double) pullProgress < 0.1D)) {
                    if (!world.field_9236) {
                        class_1667 arrowEntity = new class_1667(world, playerEntity, arrowStack, stack);
                        arrowEntity.method_24919(playerEntity, playerEntity.method_36455(), playerEntity.method_36454(), 0.0F, pullProgress * 3.75F, 1.0F);
                        if (pullProgress == 1.0F) {
                            arrowEntity.method_7439(true);
                        }

                        stack.method_7970(1, playerEntity, class_1309.method_56079(user.method_6058()));
                        world.method_8649(arrowEntity);
                    }

                    world.method_43128(null, playerEntity.method_23317(), playerEntity.method_23318(), playerEntity.method_23321(),
                            class_3417.field_14600, class_3419.field_15248, 1.0F, 1.0F / (world.method_8409().method_43057() * 0.4F + 1.2F) + pullProgress * 0.5F);
                    
                    if (!playerEntity.method_31549().field_7477) {
                        arrowStack.method_7934(1);
                        if (arrowStack.method_7960()) {
                            playerEntity.method_31548().method_7378(arrowStack);
                        }
                    }

                    playerEntity.method_7259(class_3468.field_15372.method_14956(this));
                }
            }
        }
    }
}
