package com.adventuremod.item;

import com.adventuremod.progression.PlayerProgressionHolder;
import com.adventuremod.rpg.PlayerClass;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

public class ClassTomeItem extends class_1792 {
    public ClassTomeItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        if (user instanceof PlayerProgressionHolder holder) {
            if (!world.field_9236) {
                PlayerClass current = holder.adventuremod$getProgression().playerClass;
                user.method_7353(class_2561.method_43470("§6Current class: " + current.getName()), false);
                user.method_7353(class_2561.method_43470("§eUse §f/class <hunter|warrior|scout|none>§e to choose."), false);
            }
            return class_1271.method_22427(user.method_5998(hand));
        }
        return class_1271.method_22430(user.method_5998(hand));
    }
}
