package com.adventuremod.item;

import com.adventuremod.AdventureMod;
import com.adventuremod.armor.ModArmors;
import com.adventuremod.entity.ModEntities;
import net.minecraft.class_1792;
import net.minecraft.class_1826;
import net.minecraft.class_1829;
import net.minecraft.class_1834;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4174;
import net.minecraft.class_7923;
import net.minecraft.item.*;

public class ModItems {
    public static final class_4174 BOAR_MEAT_FOOD = new class_4174.class_4175()
            .method_19238(3)
            .method_19237(1.8f)
            .method_19242();

    public static final class_4174 COOKED_BOAR_MEAT_FOOD = new class_4174.class_4175()
            .method_19238(8)
            .method_19237(12.8f)
            .method_19242();

    public static final class_4174 VENISON_FOOD = new class_4174.class_4175()
            .method_19238(3)
            .method_19237(1.8f)
            .method_19242();

    public static final class_4174 COOKED_VENISON_FOOD = new class_4174.class_4175()
            .method_19238(8)
            .method_19237(12.8f)
            .method_19242();

    public static final class_1792 BOAR_TUSK = registerItem("boar_tusk", new class_1792(new class_1792.class_1793()));
    public static final class_1792 DEER_ANTLER = registerItem("deer_antler", new class_1792(new class_1792.class_1793()));

    public static final class_1792 RAW_BOAR_MEAT = registerItem("raw_boar_meat", new class_1792(new class_1792.class_1793().method_19265(BOAR_MEAT_FOOD)));
    public static final class_1792 COOKED_BOAR_MEAT = registerItem("cooked_boar_meat", new class_1792(new class_1792.class_1793().method_19265(COOKED_BOAR_MEAT_FOOD)));

    public static final class_1792 RAW_VENISON = registerItem("raw_venison", new class_1792(new class_1792.class_1793().method_19265(VENISON_FOOD)));
    public static final class_1792 COOKED_VENISON = registerItem("cooked_venison", new class_1792(new class_1792.class_1793().method_19265(COOKED_VENISON_FOOD)));

    public static final class_1792 BOAR_TUSK_DAGGER = registerItem("boar_tusk_dagger", new BoarTuskDaggerItem(class_1834.field_8923, new class_1792.class_1793().method_57348(class_1829.method_57394(class_1834.field_8923, 2, -1.8f))));
    public static final class_1792 ANTLER_GREATSWORD = registerItem("antler_greatsword", new AntlerGreatswordItem(class_1834.field_8923, new class_1792.class_1793().method_57348(class_1829.method_57394(class_1834.field_8923, 7, -3.2f))));
    public static final class_1792 HUNTER_BOW = registerItem("hunter_bow", new HunterBowItem(new class_1792.class_1793().method_7895(450)));

    public static final class_1792 WILD_BERRIES = registerItem("wild_berries", new WildBerryItem(new class_1792.class_1793().method_19265(new class_4174.class_4175().method_19238(1).method_19237(0.3f).method_19242())));
    public static final class_1792 CLASS_TOME = registerItem("class_tome", new ClassTomeItem(new class_1792.class_1793().method_7889(1)));

    public static final class_1792 WILD_BOAR_SPAWN_EGG = registerItem("wild_boar_spawn_egg",
            new class_1826(ModEntities.WILD_BOAR, 0x8B4513, 0x654321, new class_1792.class_1793()));
    public static final class_1792 DEER_SPAWN_EGG = registerItem("deer_spawn_egg",
            new class_1826(ModEntities.DEER, 0xA06030, 0x7A4E28, new class_1792.class_1793()));
    public static final class_1792 GUARD_VILLAGER_SPAWN_EGG = registerItem("guard_villager_spawn_egg",
            new class_1826(ModEntities.GUARD_VILLAGER, 0x3C3CB4, 0x5050C8, new class_1792.class_1793()));
    public static final class_1792 RIDEABLE_BOAR_SPAWN_EGG = registerItem("rideable_boar_spawn_egg",
            new class_1826(ModEntities.RIDEABLE_BOAR, 0x8B4513, 0x654321, new class_1792.class_1793()));
    public static final class_1792 FOREST_FOX_SPAWN_EGG = registerItem("forest_fox_spawn_egg",
            new class_1826(ModEntities.FOREST_FOX, 0xC87828, 0x32B032, new class_1792.class_1793()));
    public static final class_1792 STAG_SPIRIT_SPAWN_EGG = registerItem("stag_spirit_spawn_egg",
            new class_1826(ModEntities.STAG_SPIRIT, 0xB4DCFF, 0xFFFFC8, new class_1792.class_1793()));
    public static final class_1792 FOREST_GUARDIAN_SPAWN_EGG = registerItem("forest_guardian_spawn_egg",
            new class_1826(ModEntities.FOREST_GUARDIAN, 0x3C5028, 0x00FF00, new class_1792.class_1793()));

    private static class_1792 registerItem(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(AdventureMod.MOD_ID, name), item);
    }

    public static void registerModItems() {
        AdventureMod.LOGGER.info("Registering Mod Items for " + AdventureMod.MOD_ID);
        ModArmors.registerArmors();
    }
}
