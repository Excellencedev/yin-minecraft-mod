package com.adventuremod.item;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.minecraft.class_2390;
import net.minecraft.class_3218;
import org.joml.Vector3f;

public class BoarTuskDaggerItem extends class_1829 {
    public BoarTuskDaggerItem(class_1832 material, class_1793 settings) {
        super(material, settings);
    }

    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        target.method_37222(new class_1293(class_1294.field_5899, 60, 1), attacker);
        
        if (target.method_37908() instanceof class_3218 serverWorld) {
            class_2390 bleedParticle = new class_2390(new Vector3f(0.6f, 0.0f, 0.0f), 1.0f);
            serverWorld.method_14199(bleedParticle, 
                    target.method_23317(), target.method_23323(0.5), target.method_23321(), 
                    15, 0.2, 0.4, 0.2, 0.05);
        }
        
        return super.method_7873(stack, target, attacker);
    }
}
