package com.adventuremod.world;

import com.adventuremod.AdventureMod;
import com.adventuremod.entity.ModEntities;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2893;
import net.minecraft.class_2960;
import net.minecraft.class_3031;
import net.minecraft.class_3111;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModWorldGen {
    public static final class_3031<class_3111> HUNTER_OUTPOST_FEATURE = class_2378.method_10230(
            class_7923.field_41144,
            class_2960.method_60655(AdventureMod.MOD_ID, "hunter_outpost"),
            new HunterOutpostFeature()
    );

    public static void registerWorldGen() {
        AdventureMod.LOGGER.info("Registering World Gen for " + AdventureMod.MOD_ID);

        BiomeModifications.addFeature(
                BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13173,
                class_5321.method_29179(class_7924.field_41245, class_2960.method_60655(AdventureMod.MOD_ID, "hunter_outpost"))
        );

        BiomeModifications.addSpawn(
                BiomeSelectors.foundInOverworld(),
                class_1311.field_6294,
                ModEntities.WILD_BOAR,
                60, 2, 4
        );

        BiomeModifications.addSpawn(
                BiomeSelectors.foundInOverworld(),
                class_1311.field_6294,
                ModEntities.DEER,
                80, 2, 5
        );

        BiomeModifications.addSpawn(
                BiomeSelectors.foundInOverworld(),
                class_1311.field_17715,
                ModEntities.GUARD_VILLAGER,
                5, 1, 1
        );
    }
}
