package com.adventuremod.world;

import com.adventuremod.entity.ModEntities;
import com.adventuremod.entity.GuardVillagerEntity;
import com.adventuremod.item.ModItems;
import com.adventuremod.villager.ModVillagers;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2595;
import net.minecraft.class_3031;
import net.minecraft.class_3111;
import net.minecraft.class_3730;
import net.minecraft.class_5281;
import net.minecraft.class_5821;

public class HunterOutpostFeature extends class_3031<class_3111> {
    public HunterOutpostFeature() {
        super(class_3111.field_24893);
    }

    @Override
    public boolean method_13151(class_5821<class_3111> context) {
        class_5281 world = context.method_33652();
        class_2338 origin = context.method_33655();
        class_2338 pos = world.method_8598(net.minecraft.class_2902.class_2903.field_13194, origin);
        
        if (!world.method_8320(pos.method_10074()).method_27852(class_2246.field_10219) && !world.method_8320(pos.method_10074()).method_27852(class_2246.field_10566)) {
            return false;
        }

        // Base platform (5x5)
        for (int x = -2; x <= 2; x++) {
            for (int z = -2; z <= 2; z++) {
                class_2338 floorPos = pos.method_10069(x, -1, z);
                if (world.method_8409().method_43057() < 0.3F) {
                    world.method_8652(floorPos, class_2246.field_9989.method_9564(), 3);
                } else {
                    world.method_8652(floorPos, class_2246.field_10445.method_9564(), 3);
                }
            }
        }

        // Support Spruce Pillars (height 3)
        for (int y = 0; y < 3; y++) {
            world.method_8652(pos.method_10069(-2, y, -2), class_2246.field_10037.method_9564(), 3);
            world.method_8652(pos.method_10069(2, y, -2), class_2246.field_10037.method_9564(), 3);
            world.method_8652(pos.method_10069(-2, y, 2), class_2246.field_10037.method_9564(), 3);
            world.method_8652(pos.method_10069(2, y, 2), class_2246.field_10037.method_9564(), 3);
        }

        // Roof (5x5 Spruce slabs)
        for (int x = -2; x <= 2; x++) {
            for (int z = -2; z <= 2; z++) {
                world.method_8652(pos.method_10069(x, 3, z), class_2246.field_10071.method_9564(), 3);
            }
        }

        // Workstation & Accessories
        world.method_8652(pos.method_10069(-1, 0, -1), ModVillagers.HUNTER_TABLE.method_9564(), 3);
        world.method_8652(pos.method_10069(1, 0, -1), class_2246.field_16541.method_9564(), 3);

        // Loot Chest
        class_2338 chestPos = pos.method_10069(0, 0, 0);
        world.method_8652(chestPos, class_2246.field_10034.method_9564(), 3);
        if (world.method_8321(chestPos) instanceof class_2595 chestEntity) {
            chestEntity.method_5447(0, new class_1799(class_1802.field_8687, world.method_8409().method_43048(5) + 2));
            chestEntity.method_5447(1, new class_1799(class_1802.field_8107, world.method_8409().method_43048(12) + 6));
            chestEntity.method_5447(2, new class_1799(ModItems.BOAR_TUSK, world.method_8409().method_43048(2) + 1));
            chestEntity.method_5447(3, new class_1799(ModItems.DEER_ANTLER, world.method_8409().method_43048(2) + 1));
            if (world.method_8409().method_43057() < 0.25F) {
                chestEntity.method_5447(4, new class_1799(ModItems.BOAR_TUSK_DAGGER, 1));
            }
        }

        // Guard Spawn
        GuardVillagerEntity guard = ModEntities.GUARD_VILLAGER.method_5883(world.method_8410());
        if (guard != null) {
            guard.method_5808(pos.method_10263() + 0.5D, pos.method_10264(), pos.method_10260() + 1.5D, 0.0F, 0.0F);
            guard.method_5943(world, world.method_8404(pos), class_3730.field_16474, null);
            world.method_30771(guard);
        }

        return true;
    }
}
