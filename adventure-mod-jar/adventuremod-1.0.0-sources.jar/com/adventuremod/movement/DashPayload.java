package com.adventuremod.movement;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record DashPayload(boolean active) implements class_8710 {
    public static final class_8710.class_9154<DashPayload> ID = new class_8710.class_9154<>(class_2960.method_60655("adventuremod", "dash"));
    public static final class_9139<class_2540, DashPayload> CODEC = class_9139.method_56434(
            class_9135.field_48547, DashPayload::active,
            DashPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
