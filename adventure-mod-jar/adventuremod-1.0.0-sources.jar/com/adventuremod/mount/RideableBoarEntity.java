package com.adventuremod.mount;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1341;
import net.minecraft.class_1347;
import net.minecraft.class_1361;
import net.minecraft.class_1374;
import net.minecraft.class_1376;
import net.minecraft.class_1391;
import net.minecraft.class_1394;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5146;
import net.minecraft.entity.ai.goal.*;
import org.jetbrains.annotations.Nullable;

public class RideableBoarEntity extends class_1429 implements class_5146 {
    private boolean saddled = false;

    public RideableBoarEntity(class_1299<? extends class_1429> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new class_1347(this));
        this.field_6201.method_6277(1, new class_1374(this, 1.5D));
        this.field_6201.method_6277(2, new class_1391(this, 1.1D, class_1856.method_8091(class_1802.field_8179, class_1802.field_8567), false));
        this.field_6201.method_6277(3, new class_1341(this, 1.0D));
        this.field_6201.method_6277(4, new class_1394(this, 0.8D));
        this.field_6201.method_6277(5, new class_1361(this, class_1657.class, 6.0F));
        this.field_6201.method_6277(6, new class_1376(this));
    }

    public static class_5132.class_5133 createMountAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 30.0D)
                .method_26868(class_5134.field_23719, 0.25D)
                .method_26868(class_5134.field_47761, 1.0D);
    }

    @Override
    public boolean method_6765() {
        return this.method_5805() && !this.method_6109();
    }

    @Override
    public void method_6576(class_1799 stack, @Nullable class_3419 soundCategory) {
        this.saddled = true;
        if (soundCategory != null) {
            this.method_5783(class_3417.field_14824, 0.5F, 1.0F);
        }
    }

    @Override
    public boolean method_6725() {
        return this.saddled;
    }

    @Override
    public class_3414 method_45328() {
        return class_3417.field_14824;
    }

    @Override
    public class_1269 method_5992(class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (stack.method_31574(class_1802.field_8175) && this.method_6765() && !this.method_6725()) {
            if (!player.method_31549().field_7477) stack.method_7934(1);
            this.method_6576(stack, class_3419.field_15248);
            return class_1269.field_5812;
        }
        if (this.method_6725() && !this.method_5782() && !player.method_21823()) {
            if (!this.method_37908().field_9236) {
                player.method_5804(this);
            }
            return class_1269.field_5812;
        }
        return super.method_5992(player, hand);
    }

    @Override
    public void method_6091(net.minecraft.class_243 movementInput) {
        if (this.method_6725() && this.method_5782() && this.method_31483() instanceof class_1657 player) {
            // Snap the boar to face the player's yaw so steering feels natural.
            this.method_36456(player.method_36454());
            this.field_5982 = this.method_36454();
            this.method_36457(player.method_36455() * 0.5F);
            this.field_6283 = this.method_36454();
            this.field_6241 = this.field_6283;
        }
        super.method_6091(movementInput);
    }

    @Nullable
    @Override
    public class_1296 method_5613(class_3218 world, class_1296 entity) {
        return null;
    }

    @Override
    public boolean method_6481(class_1799 stack) {
        return stack.method_31574(class_1802.field_8179) || stack.method_31574(class_1802.field_8567);
    }
}
