package com.adventuremod.entity;

import com.adventuremod.item.ModItems;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1338;
import net.minecraft.class_1341;
import net.minecraft.class_1347;
import net.minecraft.class_1361;
import net.minecraft.class_1376;
import net.minecraft.class_1391;
import net.minecraft.class_1394;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.entity.ai.goal.*;
import org.jetbrains.annotations.Nullable;

public class DeerEntity extends class_1429 {
    private static final class_2940<Boolean> HAS_ANTLERS = class_2945.method_12791(DeerEntity.class, class_2943.field_13323);
    
    private int antlerTimer = 6000; // 5 minutes to shed/regrow antler cycle

    public DeerEntity(class_1299<? extends class_1429> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new class_1347(this));
        this.field_6201.method_6277(1, new DeerFleeGoal(this, 1.4D));
        this.field_6201.method_6277(2, new class_1391(this, 1.1D, class_1856.method_8091(class_1802.field_8861, class_1802.field_8279), false));
        this.field_6201.method_6277(3, new class_1341(this, 1.0D));
        this.field_6201.method_6277(4, new class_1394(this, 0.8D));
        this.field_6201.method_6277(5, new class_1361(this, class_1657.class, 6.0F));
        this.field_6201.method_6277(6, new class_1376(this));
    }

    public static class_5132.class_5133 createDeerAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 16.0D)
                .method_26868(class_5134.field_23719, 0.32D);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(HAS_ANTLERS, true);
    }

    public boolean hasAntlers() {
        return this.field_6011.method_12789(HAS_ANTLERS);
    }

    public void setHasAntlers(boolean hasAntlers) {
        this.field_6011.method_12778(HAS_ANTLERS, hasAntlers);
    }

    @Override
    public void method_6007() {
        super.method_6007();
        if (!this.method_37908().field_9236) {
            if (this.antlerTimer > 0) {
                this.antlerTimer--;
            } else {
                this.antlerTimer = 6000; // Reset
                if (this.hasAntlers()) {
                    this.setHasAntlers(false);
                    this.method_5706(ModItems.DEER_ANTLER);
                    this.method_5783(class_3417.field_15219, 1.0F, 0.8F);
                } else {
                    this.setHasAntlers(true);
                }
            }
        }
    }

    @Nullable
    @Override
    public class_1296 method_5613(class_3218 world, class_1296 entity) {
        return ModEntities.DEER.method_5883(world);
    }

    @Override
    public boolean method_6481(class_1799 stack) {
        return stack.method_31574(class_1802.field_8861) || stack.method_31574(class_1802.field_8279);
    }

    @Override
    protected class_3414 method_5994() {
        return class_3417.field_29809;
    }

    @Override
    protected class_3414 method_6011(class_1282 source) {
        return class_3417.field_29811;
    }

    @Override
    protected class_3414 method_6002() {
        return class_3417.field_29810;
    }

    public static class DeerFleeGoal extends class_1338<class_1657> {
        private final DeerEntity deer;

        public DeerFleeGoal(DeerEntity deer, double speed) {
            super(deer, class_1657.class, 12.0F, speed, speed);
            this.deer = deer;
        }

        @Override
        public boolean method_6264() {
            class_1657 player = this.deer.method_37908().method_18460(this.deer, 12.0D);
            if (player != null) {
                // If player is sprinting, flee from 12 blocks
                if (player.method_5624()) {
                    return super.method_6264();
                }
                // If player is sneaking or holding tempt items, don't flee
                if (player.method_5715() || player.method_24518(class_1802.field_8861) || player.method_24518(class_1802.field_8279)) {
                    return false;
                }
                // Otherwise, flee from 6 blocks
                if (this.deer.method_5858(player) < 36.0D) {
                    return super.method_6264();
                }
            }
            return false;
        }
    }
}
