package com.adventuremod.entity;

import com.adventuremod.ai.TrackOwnerTargetGoal;
import net.minecraft.class_1266;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1315;
import net.minecraft.class_1321;
import net.minecraft.class_1347;
import net.minecraft.class_1350;
import net.minecraft.class_1361;
import net.minecraft.class_1366;
import net.minecraft.class_1376;
import net.minecraft.class_1386;
import net.minecraft.class_1394;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1406;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3730;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5425;
import net.minecraft.entity.ai.goal.*;
import org.jetbrains.annotations.Nullable;

public class GuardVillagerEntity extends class_1321 {

    public GuardVillagerEntity(class_1299<? extends class_1321> entityType, class_1937 world) {
        super(entityType, world);
        this.method_6173(false, false);
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new class_1347(this));
        this.field_6201.method_6277(1, new class_1386(this));
        this.field_6201.method_6277(2, new class_1366(this, 1.25D, true));
        this.field_6201.method_6277(3, new class_1350(this, 1.1D, 5.0F, 2.0F));
        this.field_6201.method_6277(4, new class_1394(this, 0.8D));
        this.field_6201.method_6277(5, new class_1361(this, class_1657.class, 8.0F));
        this.field_6201.method_6277(6, new class_1376(this));

        this.field_6185.method_6277(1, new TrackOwnerTargetGoal(this));
        this.field_6185.method_6277(2, new class_1406(this));
        this.field_6185.method_6277(3, new class_1399(this).method_6318());
        this.field_6185.method_6277(4, new class_1400<>(this, class_1588.class, 10, true, false, 
                entity -> !(entity instanceof net.minecraft.class_1548))); // Don't fight creepers to avoid griefing
    }

    public static class_5132.class_5133 createGuardAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 30.0D)
                .method_26868(class_5134.field_23719, 0.28D)
                .method_26868(class_5134.field_23721, 5.0D);
    }

    @Override
    public class_1315 method_5943(class_5425 world, class_1266 difficulty, class_3730 spawnReason, @Nullable class_1315 entityData) {
        class_1315 data = super.method_5943(world, difficulty, spawnReason, entityData);
        this.method_5673(class_1304.field_6173, new class_1799(class_1802.field_8371));
        this.method_5673(class_1304.field_6171, new class_1799(class_1802.field_8255));
        return data;
    }

    @Override
    public void method_6007() {
        super.method_6007();
        if (!this.method_37908().field_9236) {
            class_1309 target = this.method_5968();
            if (target != null && this.method_5858(target) < 16.0D) {
                // Raise shield 30% of the time in close combat
                if (this.field_5974.method_43057() < 0.30F && !this.method_6039()) {
                    this.method_6019(class_1268.field_5810);
                } else if (this.field_5974.method_43057() < 0.15F && this.method_6039()) {
                    this.method_6021();
                }
            } else if (this.method_6039()) {
                this.method_6021();
            }
        }
    }

    @Override
    public class_1269 method_5992(class_1657 player, class_1268 hand) {
        class_1799 itemStack = player.method_5998(hand);
        
        if (this.method_6181()) {
            if (this.method_6171(player)) {
                if (itemStack.method_31574(class_1802.field_8229) || itemStack.method_31574(class_1802.field_8176) || itemStack.method_31574(class_1802.field_8261)) {
                    if (this.method_6032() < this.method_6063()) {
                        this.method_6025(6.0F);
                        if (!player.method_31549().field_7477) {
                            itemStack.method_7934(1);
                        }
                        this.method_5783(class_3417.field_20614, 1.0F, 1.0F);
                        this.method_37908().method_8406(class_2398.field_11211, this.method_23322(1.0D), this.method_23319() + 0.5D, this.method_23325(1.0D), 0.0D, 0.0D, 0.0D);
                        return class_1269.field_5812;
                    }
                }
                
                // Toggle follow/sit
                if (!this.method_37908().field_9236) {
                    this.method_24346(!this.method_24345());
                    this.field_6189.method_6340();
                    this.method_5980(null);
                }
                return class_1269.field_5812;
            }
        } else {
            if (itemStack.method_31574(class_1802.field_8733) || itemStack.method_31574(class_1802.field_8463)) {
                if (!player.method_31549().field_7477) {
                    itemStack.method_7934(1);
                }
                if (!this.method_37908().field_9236) {
                    if (this.field_5974.method_43048(3) == 0) {
                        this.method_6170(player);
                        this.field_6189.method_6340();
                        this.method_5980(null);
                        this.method_37908().method_8421(this, (byte) 7); // Heart particles
                    } else {
                        this.method_37908().method_8421(this, (byte) 6); // Smoke particles
                    }
                }
                return class_1269.field_5812;
            }
        }
        
        return super.method_5992(player, hand);
    }

    @Nullable
    @Override
    public class_1296 method_5613(class_3218 world, class_1296 entity) {
        return null; // Guards do not reproduce
    }

    @Override
    public boolean method_6481(class_1799 stack) {
        return false; // Guards cannot be bred
    }

    @Override
    protected class_3414 method_5994() {
        return class_3417.field_15175;
    }

    @Override
    protected class_3414 method_6011(class_1282 source) {
        return class_3417.field_15139;
    }

    @Override
    protected class_3414 method_6002() {
        return class_3417.field_15225;
    }
}
