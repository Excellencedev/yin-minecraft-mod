package com.adventuremod.entity;

import com.adventuremod.AdventureMod;
import com.adventuremod.bosses.ForestGuardianBossEntity;
import com.adventuremod.mount.RideableBoarEntity;
import com.adventuremod.mythics.StagSpiritEntity;
import com.adventuremod.pets.ForestFoxEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModEntities {
    public static final class_1299<WildBoarEntity> WILD_BOAR = class_2378.method_10230(
            class_7923.field_41177,
            class_2960.method_60655(AdventureMod.MOD_ID, "wild_boar"),
            class_1299.class_1300.method_5903(WildBoarEntity::new, class_1311.field_6294)
                    .method_17687(0.9F, 0.9F)
                    .method_5905("wild_boar")
    );

    public static final class_1299<DeerEntity> DEER = class_2378.method_10230(
            class_7923.field_41177,
            class_2960.method_60655(AdventureMod.MOD_ID, "deer"),
            class_1299.class_1300.method_5903(DeerEntity::new, class_1311.field_6294)
                    .method_17687(0.8F, 1.6F)
                    .method_5905("deer")
    );

    public static final class_1299<GuardVillagerEntity> GUARD_VILLAGER = class_2378.method_10230(
            class_7923.field_41177,
            class_2960.method_60655(AdventureMod.MOD_ID, "guard_villager"),
            class_1299.class_1300.method_5903(GuardVillagerEntity::new, class_1311.field_6294)
                    .method_17687(0.6F, 1.95F)
                    .method_5905("guard_villager")
    );

    public static final class_1299<RideableBoarEntity> RIDEABLE_BOAR = class_2378.method_10230(
            class_7923.field_41177,
            class_2960.method_60655(AdventureMod.MOD_ID, "rideable_boar"),
            class_1299.class_1300.method_5903(RideableBoarEntity::new, class_1311.field_6294)
                    .method_17687(0.9F, 0.9F)
                    .method_5905("rideable_boar")
    );

    public static final class_1299<ForestFoxEntity> FOREST_FOX = class_2378.method_10230(
            class_7923.field_41177,
            class_2960.method_60655(AdventureMod.MOD_ID, "forest_fox"),
            class_1299.class_1300.method_5903(ForestFoxEntity::new, class_1311.field_6294)
                    .method_17687(0.6F, 0.7F)
                    .method_5905("forest_fox")
    );

    public static final class_1299<StagSpiritEntity> STAG_SPIRIT = class_2378.method_10230(
            class_7923.field_41177,
            class_2960.method_60655(AdventureMod.MOD_ID, "stag_spirit"),
            class_1299.class_1300.method_5903(StagSpiritEntity::new, class_1311.field_6302)
                    .method_17687(1.2F, 2.0F)
                    .method_5905("stag_spirit")
    );

    public static final class_1299<ForestGuardianBossEntity> FOREST_GUARDIAN = class_2378.method_10230(
            class_7923.field_41177,
            class_2960.method_60655(AdventureMod.MOD_ID, "forest_guardian"),
            class_1299.class_1300.method_5903(ForestGuardianBossEntity::new, class_1311.field_6302)
                    .method_17687(1.6F, 2.8F)
                    .method_5905("forest_guardian")
    );

    public static void registerAttributes() {
        FabricDefaultAttributeRegistry.register(WILD_BOAR, WildBoarEntity.createBoarAttributes());
        FabricDefaultAttributeRegistry.register(DEER, DeerEntity.createDeerAttributes());
        FabricDefaultAttributeRegistry.register(GUARD_VILLAGER, GuardVillagerEntity.createGuardAttributes());
        FabricDefaultAttributeRegistry.register(RIDEABLE_BOAR, RideableBoarEntity.createMountAttributes());
        FabricDefaultAttributeRegistry.register(FOREST_FOX, ForestFoxEntity.createFoxAttributes());
        FabricDefaultAttributeRegistry.register(STAG_SPIRIT, StagSpiritEntity.createStagAttributes());
        FabricDefaultAttributeRegistry.register(FOREST_GUARDIAN, ForestGuardianBossEntity.createBossAttributes());
    }
}
