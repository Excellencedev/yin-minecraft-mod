package com.adventuremod.entity;

import com.adventuremod.item.ModItems;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1341;
import net.minecraft.class_1347;
import net.minecraft.class_1361;
import net.minecraft.class_1366;
import net.minecraft.class_1367;
import net.minecraft.class_1376;
import net.minecraft.class_1391;
import net.minecraft.class_1394;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_4538;
import net.minecraft.class_4802;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5354;
import net.minecraft.class_6019;
import net.minecraft.entity.ai.goal.*;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

public class WildBoarEntity extends class_1429 implements class_5354 {
    private static final class_6019 ANGER_TIME_RANGE = class_4802.method_24505(20, 39);
    private int angerTime;
    @Nullable
    private UUID angryAt;
    private int chargeCooldown = 0;

    public WildBoarEntity(class_1299<? extends class_1429> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new class_1347(this));
        this.field_6201.method_6277(1, new class_1366(this, 1.25D, true));
        this.field_6201.method_6277(2, new EatCropsGoal(this, 1.0D));
        this.field_6201.method_6277(3, new class_1391(this, 1.1D, class_1856.method_8091(class_1802.field_8179, class_1802.field_8567), false));
        this.field_6201.method_6277(4, new class_1341(this, 1.0D));
        this.field_6201.method_6277(5, new class_1394(this, 0.8D));
        this.field_6201.method_6277(6, new class_1361(this, class_1657.class, 6.0F));
        this.field_6201.method_6277(7, new class_1376(this));

        this.field_6185.method_6277(1, new class_1399(this).method_6318());
        this.field_6185.method_6277(2, new class_1400<>(this, class_1657.class, 10, true, false, this::method_29515));
    }

    public static class_5132.class_5133 createBoarAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 24.0D)
                .method_26868(class_5134.field_23719, 0.25D)
                .method_26868(class_5134.field_23721, 4.0D)
                .method_26868(class_5134.field_23722, 1.5D);
    }

    @Override
    public void method_6007() {
        super.method_6007();
        if (!this.method_37908().field_9236) {
            this.method_29510((class_3218) this.method_37908(), true);
            if (this.chargeCooldown > 0) {
                this.chargeCooldown--;
            }

            class_1309 target = this.method_5968();
            if (target != null && this.chargeCooldown == 0 && this.method_5858(target) > 16.0D && this.method_5858(target) < 64.0D) {
                this.performCharge(target);
            }
        }
    }

    private void performCharge(class_1309 target) {
        double dx = target.method_23317() - this.method_23317();
        double dz = target.method_23321() - this.method_23321();
        double distance = Math.sqrt(dx * dx + dz * dz);
        if (distance > 0) {
            this.method_18800(dx / distance * 0.8D, 0.25D, dz / distance * 0.8D);
            this.method_5783(class_3417.field_14615, 1.5F, 0.8F);
            this.chargeCooldown = 100; // 5 second cooldown
        }
    }

    @Nullable
    @Override
    public class_1296 method_5613(class_3218 world, class_1296 entity) {
        return ModEntities.WILD_BOAR.method_5883(world);
    }

    @Override
    public boolean method_6481(class_1799 stack) {
        return stack.method_31574(class_1802.field_8179) || stack.method_31574(class_1802.field_8567);
    }

    @Override
    public int method_29507() {
        return this.angerTime;
    }

    @Override
    public void method_29514(int angerTime) {
        this.angerTime = angerTime;
    }

    @Nullable
    @Override
    public UUID method_29508() {
        return this.angryAt;
    }

    @Override
    public void method_29513(@Nullable UUID angryAt) {
        this.angryAt = angryAt;
    }

    @Override
    public void method_29509() {
        this.method_29514(ANGER_TIME_RANGE.method_35008(this.field_5974));
    }

    @Override
    protected class_3414 method_5994() {
        return class_3417.field_14615;
    }

    @Override
    protected class_3414 method_6011(class_1282 source) {
        return class_3417.field_14750;
    }

    @Override
    protected class_3414 method_6002() {
        return class_3417.field_14689;
    }

    public static class EatCropsGoal extends class_1367 {
        private final WildBoarEntity boar;

        public EatCropsGoal(WildBoarEntity boar, double speed) {
            super(boar, speed, 8);
            this.boar = boar;
        }

        @Override
        public boolean method_6264() {
            if (this.boar.method_6109()) return false;
            return super.method_6264();
        }

        @Override
        protected boolean method_6296(class_4538 world, class_2338 pos) {
            class_2680 state = world.method_8320(pos);
            if (state.method_27852(class_2246.field_10293) || state.method_27852(class_2246.field_10609) || state.method_27852(class_2246.field_10247)) {
                if (state.method_26204() instanceof class_2302 cropBlock) {
                    return cropBlock.method_9825(state);
                }
            }
            return false;
        }

        @Override
        public void method_6268() {
            super.method_6268();
            if (this.method_6295()) {
                class_1937 world = this.boar.method_37908();
                class_2338 pos = this.method_30953();
                class_2680 state = world.method_8320(pos);
                if (state.method_26204() instanceof class_2302) {
                    world.method_22352(pos, false);
                    this.boar.method_6025(4.0F);
                    this.boar.method_5783(class_3417.field_14615, 1.0F, 0.7F);
                    this.method_6270();
                }
            }
        }
    }
}
