package com.adventuremod.hunting;

import com.adventuremod.item.ModItems;
import com.adventuremod.skills.PlayerSkills;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;

public class ButcheringTableBlock extends class_2248 {
    private static final Map<class_1792, class_1792> RAW_TO_BUTCHERED = new HashMap<>();
    static {
        // All raw meats yield boar meat in this mod's theme
        RAW_TO_BUTCHERED.put(class_1802.field_8389, ModItems.RAW_BOAR_MEAT);
        RAW_TO_BUTCHERED.put(class_1802.field_8046, ModItems.RAW_BOAR_MEAT);
        RAW_TO_BUTCHERED.put(class_1802.field_8726, ModItems.RAW_BOAR_MEAT);
        RAW_TO_BUTCHERED.put(class_1802.field_8748, ModItems.RAW_BOAR_MEAT);
        RAW_TO_BUTCHERED.put(class_1802.field_8504, ModItems.RAW_BOAR_MEAT);
    }

    public ButcheringTableBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        class_1799 stack = player.method_6047();
        class_1792 butchered = RAW_TO_BUTCHERED.get(stack.method_7909());
        if (butchered == null) {
            return class_1269.field_5811;
        }

        if (world.field_9236) {
            return class_1269.field_5812;
        }

        int count = stack.method_7947();
        // Each raw meat produces 1 butchered meat + a 50% chance of a bone
        stack.method_7934(count);
        player.method_31548().method_7398(new class_1799(butchered, count));
        int boneCount = (count + 1) / 2; // 1 bone per 2 raw meats, rounded up
        player.method_31548().method_7398(new class_1799(class_1802.field_8606, boneCount));

        // Award hunting XP
        PlayerSkills.addHuntingXp(player, count * 5);

        world.method_8396(null, pos, class_3417.field_14706, class_3419.field_15245, 1.0F, 1.0F);
        return class_1269.field_5812;
    }
}
