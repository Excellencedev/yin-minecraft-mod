package com.adventuremod.hunting;

import com.adventuremod.AdventureMod;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

public class ModHunting {
    public static final class_2248 BUTCHERING_TABLE = class_2378.method_10230(
            class_7923.field_41175,
            class_2960.method_60655(AdventureMod.MOD_ID, "butchering_table"),
            new ButcheringTableBlock(class_4970.class_2251.method_9630(class_2246.field_16329))
    );

    public static final class_1792 BUTCHERING_TABLE_ITEM = class_2378.method_10230(
            class_7923.field_41178,
            class_2960.method_60655(AdventureMod.MOD_ID, "butchering_table"),
            new class_1747(BUTCHERING_TABLE, new class_1792.class_1793())
    );

    public static void registerHunting() {
        AdventureMod.LOGGER.info("Registering Hunting for " + AdventureMod.MOD_ID);
    }
}
