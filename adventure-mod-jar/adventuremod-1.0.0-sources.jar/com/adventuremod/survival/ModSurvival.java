package com.adventuremod.survival;

import com.adventuremod.AdventureMod;
import com.adventuremod.progression.PlayerProgressionHolder;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.class_1271;
import net.minecraft.class_1802;
import net.minecraft.class_2561;

public class ModSurvival {
    public static void registerSurvival() {
        AdventureMod.LOGGER.info("Registering Survival for " + AdventureMod.MOD_ID);

        // Drinking water bottles, potions, milk restores thirst.
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.field_9236 || !(player instanceof PlayerProgressionHolder holder)) {
                return class_1271.method_22430(player.method_5998(hand));
            }
            ThirstManager thirst = holder.adventuremod$getProgression().thirst;
            var stack = player.method_5998(hand);

            if (stack.method_31574(class_1802.field_8574)) {
                thirst.drink(6, 1.0f);
                if (player instanceof net.minecraft.class_3222 sp) {
                    sp.method_7353(class_2561.method_43470("§b[Thirst] +6 (now " + thirst.getThirstLevel() + "/20)"), true);
                }
            } else if (stack.method_31574(class_1802.field_8103)) {
                thirst.drink(8, 2.0f);
                if (player instanceof net.minecraft.class_3222 sp) {
                    sp.method_7353(class_2561.method_43470("§b[Thirst] +8 (now " + thirst.getThirstLevel() + "/20)"), true);
                }
            } else if (stack.method_31574(class_1802.field_8705)) {
                thirst.drink(20, 5.0f);
                if (player instanceof net.minecraft.class_3222 sp) {
                    sp.method_7353(class_2561.method_43470("§b[Thirst] fully quenched!"), true);
                }
            }
            return class_1271.method_22430(stack);
        });
    }
}
