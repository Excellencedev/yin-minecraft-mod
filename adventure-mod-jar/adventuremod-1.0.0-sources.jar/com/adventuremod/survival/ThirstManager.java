package com.adventuremod.survival;

import com.adventuremod.progression.PlayerProgressionHolder;
import net.minecraft.class_1657;
import net.minecraft.class_2487;

public class ThirstManager {
    public static final int MAX = 20;
    private int thirstLevel = MAX;
    private float thirstSaturation = 5.0f;
    private int thirstTickTimer = 0;

    public void tick(class_1657 player) {
        if (player.method_7337() || player.method_7325()) return;

        thirstTickTimer++;
        if (thirstTickTimer >= 200) {
            thirstTickTimer = 0;
            if (player.method_5624()) {
                addThirst(-1);
            }
        }

        if (thirstLevel <= 0) {
            player.method_5643(player.method_48923().method_48825(), 1.0f);
        }
    }

    public void addThirst(int amount) {
        thirstLevel = Math.max(0, Math.min(MAX, thirstLevel + amount));
    }

    public void drink(int amount, float saturation) {
        thirstLevel = Math.min(MAX, thirstLevel + amount);
        thirstSaturation = Math.min(thirstSaturation + saturation, thirstLevel);
    }

    public int getThirstLevel() { return thirstLevel; }
    public float getThirstSaturation() { return thirstSaturation; }

    public void replaceWith(ThirstManager other) {
        this.thirstLevel = other.thirstLevel;
        this.thirstSaturation = other.thirstSaturation;
    }

    public class_2487 toNbt() {
        class_2487 tag = new class_2487();
        tag.method_10569("thirstLevel", thirstLevel);
        tag.method_10548("thirstSaturation", thirstSaturation);
        return tag;
    }

    public static ThirstManager fromNbt(class_2487 tag) {
        ThirstManager t = new ThirstManager();
        t.thirstLevel = tag.method_10550("thirstLevel");
        t.thirstSaturation = tag.method_10583("thirstSaturation");
        return t;
    }

    public static ThirstManager get(class_1657 player) {
        if (player instanceof PlayerProgressionHolder h) {
            return h.adventuremod$getProgression().thirst;
        }
        return null;
    }
}
