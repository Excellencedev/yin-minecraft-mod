package com.adventuremod.farming;

import com.adventuremod.AdventureMod;
import com.adventuremod.item.ModItems;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

public class ModFarming {
    public static final class_2248 WILD_BERRY_BUSH = class_2378.method_10230(
            class_7923.field_41175,
            class_2960.method_60655(AdventureMod.MOD_ID, "wild_berry_bush"),
            new BerryBushBlock(class_4970.class_2251.method_9630(class_2246.field_16999))
    );

    public static final class_1792 WILD_BERRY_BUSH_ITEM = class_2378.method_10230(
            class_7923.field_41178,
            class_2960.method_60655(AdventureMod.MOD_ID, "wild_berry_bush"),
            new class_1747(WILD_BERRY_BUSH, new class_1792.class_1793())
    );

    public static void registerFarming() {
        AdventureMod.LOGGER.info("Registering Farming for " + AdventureMod.MOD_ID);
    }
}
