package com.adventuremod.ai;

import java.util.EnumSet;
import net.minecraft.class_1309;
import net.minecraft.class_1321;
import net.minecraft.class_1405;
import net.minecraft.class_4051;

/**
 * Replacement for the 1.20.x TrackOwnerTargetGoal that is no longer public in 1.21.1 yarn.
 * Sets this tameable's target to whatever its owner is currently attacking.
 */
public class TrackOwnerTargetGoal extends class_1405 {
    private final class_1321 tameable;
    private class_1309 defending;
    private int lastAttackedTime;

    public TrackOwnerTargetGoal(class_1321 tameable) {
        super(tameable, false);
        this.tameable = tameable;
        this.method_6265(EnumSet.of(class_4134.field_18408));
    }

    @Override
    public boolean method_6264() {
        if (!this.tameable.method_6181() || this.tameable.method_24345()) return false;
        class_1309 owner = this.tameable.method_35057();
        if (owner == null) return false;
        this.defending = owner.method_6052();
        int time = owner.method_6117();
        return time != this.lastAttackedTime && this.method_6328(this.defending, class_4051.field_18092);
    }

    @Override
    public void method_6269() {
        this.tameable.method_5980(this.defending);
        class_1309 owner = this.tameable.method_35057();
        if (owner != null) this.lastAttackedTime = owner.method_6117();
        super.method_6269();
    }
}
