package com.adventuremod.armor;

import com.adventuremod.AdventureMod;
import com.adventuremod.item.ModItems;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_1856;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class ModArmors {

    public static final class_6880<class_1741> BOAR_HIDE_MATERIAL = registerArmorMaterial("boar_hide",
            Map.of(
                    class_1738.class_8051.field_41934, 2,
                    class_1738.class_8051.field_41935, 5,
                    class_1738.class_8051.field_41936, 4,
                    class_1738.class_8051.field_41937, 2
            ), 10, class_3417.field_14581, 0.5F, 0.0F,
            () -> class_1856.method_8091(ModItems.BOAR_TUSK));

    public static final class_6880<class_1741> DEER_HIDE_MATERIAL = registerArmorMaterial("deer_hide",
            Map.of(
                    class_1738.class_8051.field_41934, 2,
                    class_1738.class_8051.field_41935, 5,
                    class_1738.class_8051.field_41936, 4,
                    class_1738.class_8051.field_41937, 2
            ), 12, class_3417.field_14581, 0.5F, 0.0F,
            () -> class_1856.method_8091(ModItems.DEER_ANTLER));

    public static final class_1792 BOAR_HIDE_HELMET = registerArmorItem("boar_hide_helmet", BOAR_HIDE_MATERIAL, class_1738.class_8051.field_41934);
    public static final class_1792 BOAR_HIDE_CHESTPLATE = registerArmorItem("boar_hide_chestplate", BOAR_HIDE_MATERIAL, class_1738.class_8051.field_41935);
    public static final class_1792 BOAR_HIDE_LEGGINGS = registerArmorItem("boar_hide_leggings", BOAR_HIDE_MATERIAL, class_1738.class_8051.field_41936);
    public static final class_1792 BOAR_HIDE_BOOTS = registerArmorItem("boar_hide_boots", BOAR_HIDE_MATERIAL, class_1738.class_8051.field_41937);

    public static final class_1792 DEER_HIDE_HELMET = registerArmorItem("deer_hide_helmet", DEER_HIDE_MATERIAL, class_1738.class_8051.field_41934);
    public static final class_1792 DEER_HIDE_CHESTPLATE = registerArmorItem("deer_hide_chestplate", DEER_HIDE_MATERIAL, class_1738.class_8051.field_41935);
    public static final class_1792 DEER_HIDE_LEGGINGS = registerArmorItem("deer_hide_leggings", DEER_HIDE_MATERIAL, class_1738.class_8051.field_41936);
    public static final class_1792 DEER_HIDE_BOOTS = registerArmorItem("deer_hide_boots", DEER_HIDE_MATERIAL, class_1738.class_8051.field_41937);

    private static class_6880<class_1741> registerArmorMaterial(String name, Map<class_1738.class_8051, Integer> defense,
                                                                      int enchantability, class_6880<net.minecraft.class_3414> equipSound,
                                                                      float toughness, float knockbackResistance,
                                                                      Supplier<class_1856> repairIngredient) {
        class_2960 id = class_2960.method_60655(AdventureMod.MOD_ID, name);
        class_1741 material = new class_1741(defense, enchantability, equipSound, repairIngredient, List.of(), toughness, knockbackResistance);
        return class_6880.method_40223(class_2378.method_10230(class_7923.field_48976, id, material));
    }

    private static class_1792 registerArmorItem(String name, class_6880<class_1741> material, class_1738.class_8051 type) {
        return class_2378.method_10230(
                class_7923.field_41178,
                class_2960.method_60655(AdventureMod.MOD_ID, name),
                new class_1738(material, type, new class_1792.class_1793().method_7889(1))
        );
    }

    public static void registerArmors() {
        AdventureMod.LOGGER.info("Registering Armors for " + AdventureMod.MOD_ID);
    }
}
