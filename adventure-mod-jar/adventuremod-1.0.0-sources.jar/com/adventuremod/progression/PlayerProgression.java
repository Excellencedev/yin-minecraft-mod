package com.adventuremod.progression;

import com.adventuremod.rpg.PlayerClass;
import com.adventuremod.skills.PlayerSkills;
import com.adventuremod.survival.ThirstManager;
import net.minecraft.class_2487;

/**
 * Per-player progression container that wraps skills, thirst, and class.
 * Persists through player death and respawning.
 */
public class PlayerProgression {
    public final PlayerSkills skills = new PlayerSkills();
    public final ThirstManager thirst = new ThirstManager();
    public PlayerClass playerClass = PlayerClass.NONE;

    public class_2487 toNbt() {
        class_2487 tag = new class_2487();
        tag.method_10566("Skills", skills.toNbt());
        tag.method_10566("Thirst", thirst.toNbt());
        tag.method_10582("Class", playerClass.getName());
        return tag;
    }

    public static PlayerProgression fromNbt(class_2487 tag) {
        PlayerProgression p = new PlayerProgression();
        if (tag.method_10545("Skills")) {
            // skills already set; copy values
            class_2487 s = tag.method_10562("Skills");
            // Re-attach by mutating fields through addXp with a noop or use a setter
            // For simplicity we read into a new PlayerSkills and replace
            PlayerSkills loaded = PlayerSkills.fromNbt(s);
            p.skills.replaceWith(loaded);
        }
        if (tag.method_10545("Thirst")) {
            ThirstManager loaded = ThirstManager.fromNbt(tag.method_10562("Thirst"));
            p.thirst.replaceWith(loaded);
        }
        if (tag.method_10545("Class")) {
            p.playerClass = PlayerClass.fromName(tag.method_10558("Class"));
        }
        return p;
    }
}
